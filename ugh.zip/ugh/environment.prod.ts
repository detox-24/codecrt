export const environment = {
  production: true,
  apiUrl: '',  // Will be set during deployment
  yjsServerUrl: ''  // Will be set during deployment
};