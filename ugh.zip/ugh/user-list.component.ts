import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="crt-screen p-3 h-full">
      <h3 class="text-xl mb-3 border-b border-matrix-darkgreen pb-2">Users Online</h3>
      
      <div class="space-y-2">
        <div *ngFor="let user of users" class="user-presence">
          <div [style.background-color]="user.color" class="user-avatar"></div>
          <span>{{ user.name }}</span>
        </div>
        
        <div *ngIf="users.length === 0" class="text-matrix-green opacity-60">
          No users connected
        </div>
      </div>
    </div>
  `
})
export class UserListComponent {
  @Input() users: any[] = [];
}