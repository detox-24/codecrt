import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionService } from '../../services/session.service';
import { SUPPORTED_LANGUAGES } from '../../models/session.model';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="flex flex-col items-center justify-center min-h-screen p-4">
      <div class="w-full max-w-md">
        <div class="text-center mb-8">
          <h1 class="text-5xl font-crt tracking-wide text-matrix-green mb-2">
            <span class="animate-flicker">></span> CodeCRT
          </h1>
          <p class="text-matrix-green opacity-80">Collaborative code editing with Matrix vibes</p>
        </div>
        
        <div class="crt-screen mb-6">
          <h2 class="text-2xl mb-4">Create Session</h2>
          <form [formGroup]="createForm" (ngSubmit)="createSession()" class="space-y-4">
            <div>
              <label for="title" class="block mb-1">Session Title</label>
              <input id="title" formControlName="title" placeholder="My Coding Session" class="w-full">
            </div>
            
            <div>
              <label for="username" class="block mb-1">Your Username</label>
              <input id="username" formControlName="username" placeholder="Neo" class="w-full">
            </div>
            
            <div>
              <label for="language" class="block mb-1">Language</label>
              <select id="language" formControlName="language" class="w-full bg-black border border-matrix-green text-matrix-green px-3 py-2 rounded-sm">
                <option *ngFor="let lang of languages" [value]="lang.value">{{ lang.name }}</option>
              </select>
            </div>
            
            <button type="submit" [disabled]="createForm.invalid" class="w-full">
              Create Session
            </button>
          </form>
        </div>
        
        <div class="crt-screen">
          <h2 class="text-2xl mb-4">Join Session</h2>
          <form [formGroup]="joinForm" (ngSubmit)="joinSession()" class="space-y-4">
            <div>
              <label for="sessionId" class="block mb-1">Session ID</label>
              <input id="sessionId" formControlName="sessionId" placeholder="Enter session ID" class="w-full">
            </div>
            
            <div>
              <label for="joinUsername" class="block mb-1">Your Username</label>
              <input id="joinUsername" formControlName="username" placeholder="Morpheus" class="w-full">
            </div>
            
            <button type="submit" [disabled]="joinForm.invalid" class="w-full">
              Join Session
            </button>
          </form>
        </div>
      </div>
    </div>
  `
})
export class DashboardComponent implements OnInit {
  createForm!: FormGroup;
  joinForm!: FormGroup;
  languages = SUPPORTED_LANGUAGES;

  constructor(
    private fb: FormBuilder,
    private sessionService: SessionService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.createForm = this.fb.group({
      title: ['', [Validators.required]],
      username: ['', [Validators.required]],
      language: [this.languages[0].value, [Validators.required]]
    });

    this.joinForm = this.fb.group({
      sessionId: ['', [Validators.required]],
      username: ['', [Validators.required]]
    });
  }

  createSession(): void {
    if (this.createForm.valid) {
      const formValue = this.createForm.value;
      
      const session = {
        sessionId: uuidv4(),
        title: formValue.title,
        language: formValue.language,
        createdBy: formValue.username,
        users: [{
          id: uuidv4(),
          name: formValue.username,
          color: this.getRandomColor(),
          active: true,
          lastActive: new Date()
        }]
      };
      
      this.sessionService.createSession(session).subscribe(
        createdSession => {
          localStorage.setItem('username', formValue.username);
          this.router.navigate(['/editor', createdSession.sessionId]);
        },
        error => {
          console.error('Error creating session:', error);
        }
      );
    }
  }

  joinSession(): void {
    if (this.joinForm.valid) {
      const { sessionId, username } = this.joinForm.value;
      localStorage.setItem('username', username);
      this.router.navigate(['/editor', sessionId]);
    }
  }

  private getRandomColor(): string {
    const colors = [
      '#FF5733', '#33FF57', '#3357FF', '#FF33F5', 
      '#F5FF33', '#33FFF5', '#FF3333', '#33FF33'
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  }
}