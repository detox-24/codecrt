export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000',
  yjsServerUrl: 'ws://localhost:3000/yjs'
};
